function login() {
    const username = document.getElementById("username").value.trim();
    if (username === "") {
        alert("Please enter your username.");
        return;
    }
    alert("Welcome " + username + "! Redirecting to dashboard...");
    // Here you can redirect or save username for future use
}

document.getElementById("username").addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        login();
    }
});